package com.resources.copy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConfig {

/*	public static final String DB_URL= "jdbc:h2:tcp://localhost/~/test";
	static final String USER="sa";
	static final String PASS="sa";
	*/
	
	public Connection getConnection()throws ClassNotFoundException
	{
		Connection conn= null;
		try {
			Class.forName("org.h2.Driver");
			conn =DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","sa");
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
}
