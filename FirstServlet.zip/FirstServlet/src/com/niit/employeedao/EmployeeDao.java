package com.niit.employeedao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.niit.model.Employee;
import com.resources.copy.*;
public class EmployeeDao{
	Connection conn;
	DBConfig dbo=new DBConfig();
	List<Employee> list;
	
	public int Store(Employee em) {
		int a=0;
	try {
		conn = dbo.getConnection();
		
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	try {
		PreparedStatement pd=conn.prepareStatement("insert into Employee values(?,?,?,?,?,?,?)");
		Employee obj=new Employee();
		System.out.println(conn);
		
		String ID=em.getId();
		String NAME=em.getName();
		String PASSWORD=em.getPassword();
		String EMAIL=em.getEmail();
		String CONTACT=em.getContact();
		String ROLE=em.getRole();
		boolean ACTIVE=em.isActive();
		pd.setString(1, ID);
		pd.setString(2, NAME);
		pd.setString(3, EMAIL);
		pd.setString(4, PASSWORD);
		pd.setString(5, CONTACT);
		pd.setString(6, ROLE);
		pd.setBoolean(7, ACTIVE);
		a=pd.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return a;

}
	
	public Employee LoginCheck(String mail) throws ClassNotFoundException, SQLException
	{
		conn=dbo.getConnection();
		PreparedStatement pst=conn.prepareStatement("Select * from Employee where email=?");
		pst.setString(1, mail);
		ResultSet rs=pst.executeQuery();
		
		Employee objemp=new Employee();
		while(rs.next()) {
			
			String EMAIL=rs.getString(3);
			String ROLE=rs.getString(6);
			objemp.setEmail(EMAIL);
			objemp.setContact(rs.getString(5));
			objemp.setId(rs.getString(1));;
			objemp.setName(rs.getString(2));
			objemp.setPassword(rs.getString(4));
			objemp.setRole(ROLE);
		}
		return objemp;
		
	}
	
	public boolean deleteEmp(Employee e) throws ClassNotFoundException, SQLException //delete from H2 and HR view page
	{
		boolean flag=false;
		conn=dbo.getConnection();
		PreparedStatement pst=conn.prepareStatement("delete from employee where id=?");
		pst.setString(1, e.getId());
		int i=pst.executeUpdate();
		if(i!=0)
		{
			System.out.println("deleted");
			flag=true;
		}
		else
		{
			System.out.println("not deleted");
			flag=false;
		}
		return flag;
	}
	
	public boolean updateEmp(Employee e) //only to set active
	{
		boolean flag=false;
		try {
			conn=dbo.getConnection();
			PreparedStatement pst=conn.prepareStatement("update employee set active=true where id=?");
			pst.setString(1, e.getId());
			int i=pst.executeUpdate();
			if(i!=0)
			{
				System.out.println("updated");
				flag=true;
			}
			else
			{
				System.out.println("not updated");
				flag=false;
			}
		
		} catch (SQLException | ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return flag;
	
	}
	
	public List<Employee> getAllApproved() throws SQLException, ClassNotFoundException 
	{
		conn=dbo.getConnection();
		System.out.println(conn);
		list = new ArrayList<>();
		ResultSet rs;
		try {
			
			PreparedStatement pst=conn.prepareStatement("Select * from Employee where active=?");
			pst.setBoolean(1, true);
			rs=pst.executeQuery();
			while(rs.next()) 
			{
				Employee objemp=new Employee();
				objemp.setId(rs.getString(1));
				objemp.setName(rs.getString(2));
				objemp.setEmail(rs.getString(3));
				objemp.setPassword(rs.getString(4));
				objemp.setContact(rs.getString(5));
				objemp.setRole(rs.getString(6));
				objemp.setActive(rs.getBoolean(7));
				list.add(objemp);
			}
		}
			catch (SQLException em) {
				em.printStackTrace();
			}
		System.out.println(list);
		return list;
		
	}
	
	public List<Employee> getAllUnapproved() throws ClassNotFoundException, SQLException 
	{
		conn=dbo.getConnection();
		System.out.println(conn);
		list = new ArrayList<>();
		try 
		{
			PreparedStatement pst=conn.prepareStatement("Select * from Employee where active=?");
			pst.setBoolean(1, false);
			ResultSet rs=pst.executeQuery();
			while(rs.next()) 
			{
				Employee objemp=new Employee();
				System.out.println("in loop rs is "+rs );
				objemp.setId(rs.getString(1));
				objemp.setName(rs.getString(2));
				objemp.setEmail(rs.getString(3));
				objemp.setPassword(rs.getString(4));
				objemp.setContact(rs.getString(5));
				objemp.setRole(rs.getString(6));
				objemp.setActive(rs.getBoolean(7));
				System.out.println(objemp);
				list.add(objemp);
			}
		}
			catch (SQLException em) {
				em.printStackTrace();
			}
		return list;
	}		
}