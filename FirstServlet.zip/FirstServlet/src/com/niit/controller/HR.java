package com.niit.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.employeedao.EmployeeDao;
import com.niit.model.Employee;

/**
 * Servlet implementation class HR
 */
public class HR extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HR() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		List<Employee> al=new ArrayList<Employee>(); //approved =  al
		List<Employee> ul=new ArrayList<Employee>(); //unapproved = ul
		
		try {
			System.out.println("in HR.java");
			EmployeeDao empDao=new EmployeeDao();
			al=empDao.getAllApproved();
			ul=empDao.getAllUnapproved();
			request.setAttribute("alist", al);
			//System.out.println(al);
			request.setAttribute("ulist", ul);
			System.out.println(ul);
			RequestDispatcher rd=request.getRequestDispatcher("/WEB-INF/views/HRapproval.jsp");
			rd.forward(request, response);
			//request.getRequestDispatcher("HRapproval.jsp").forward(request, response);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
