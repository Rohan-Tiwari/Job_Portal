package com.niit.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.employeedao.EmployeeDao;
import com.niit.model.Employee;

/**
 * Servlet implementation class UnapprovedUser
 */
public class UnapprovedUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       Employee empobj;
       EmployeeDao empdaoObj;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UnapprovedUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		empobj=new Employee();
		empdaoObj=new EmployeeDao();
		empobj.setId(request.getParameter("empid"));
		empobj.setActive(true);
		boolean flag=false;
		try {
			flag = empdaoObj.deleteEmp(empobj);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		if(flag)
		{
			System.out.println("deleted");
		}
		else
		{
			System.out.println("not deleted");
		}
		
		RequestDispatcher rd=request.getRequestDispatcher("/HR");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
