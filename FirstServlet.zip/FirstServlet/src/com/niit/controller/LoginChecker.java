package com.niit.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.employeedao.EmployeeDao;
import com.niit.model.Employee;

/**
 * Servlet implementation class LoginChecker
 */
public class LoginChecker extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginChecker() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Employee obj=new Employee();
		String email=request.getParameter("Email");
		//System.out.println(request.getParameter("Email"));
		//String password=request.getParameter("Password");
		//System.out.println(request.getParameter("Password"));
		//String role=request.getParameter("Role");
		
		EmployeeDao empDao=new EmployeeDao();
		
		try {
			obj=empDao.LoginCheck(email);
			System.out.println("here");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		if(obj.getRole().equalsIgnoreCase("faculty"))
		{
			System.out.println("in faculty");
			response.sendRedirect("/FacultyPage");
		}
		else if(obj.getRole().equalsIgnoreCase("hr"))
		{
			System.out.println("in HR");	
			response.sendRedirect("/FirstServlet/HR");
		}
		
		else if(obj.getRole().equalsIgnoreCase("manager")) 
		{
			System.out.println("in Manager");
		}
		else
		{
			System.out.println("invalid credentials");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
