package com.niit.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.employeedao.EmployeeDao;
import com.niit.model.Employee;

/**
 * Servlet implementation class FacultyPage
 */
public class FacultyPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       Employee empobj;
       EmployeeDao empdao;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FacultyPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		empobj=new Employee();
		empdao=new EmployeeDao();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
