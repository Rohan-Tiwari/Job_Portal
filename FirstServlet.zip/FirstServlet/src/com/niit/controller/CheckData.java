package com.niit.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.employeedao.EmployeeDao;
//import com.niit.employeedao.inherit_empDao;
import com.niit.model.Employee;
//import com.resources.copy.inherit_DBConfig;

/**
 * Servlet implementation class CheckData
 */
public class CheckData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Employee obj=new Employee();
		//obj.setId(Integer.parseInt(request.getParameter("uID")););
		String Id=request.getParameter("uID");
		String Name=request.getParameter("uName");
		String Email=request.getParameter("uEmail");
		String Pass=request.getParameter("uPass");
		String Role=request.getParameter("uRole");
		String Contact=request.getParameter("uContact");
		boolean Active=true;
		
		
		//String Id1=String.valueOf(Id);
		obj.setId(Id);
		obj.setName(Name);
		obj.setEmail(Email);
		obj.setPassword(Pass);
		obj.setContact(Contact);
		obj.setRole(Role);
		
		//EmployeeDao empDao=new EmployeeDao();
		EmployeeDao empDao=new EmployeeDao();
		int i=empDao.Store(obj);
		if(i==1)
		{
			System.out.println("record Inserted");
			obj.setActive(Active);
			request.getRequestDispatcher("Login.jsp").forward(request, response);
		}
		else
		{
			System.out.println("record not Inserted");
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
